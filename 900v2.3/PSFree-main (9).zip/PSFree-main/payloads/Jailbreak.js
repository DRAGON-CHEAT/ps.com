export function GoldHEN() {
    window.payload_path = './payloads/GoldHEN/GoldHEN.bin';
}

export function HEN() {
    window.payload_path = `./payloads/HEN/HEN.bin`;
}